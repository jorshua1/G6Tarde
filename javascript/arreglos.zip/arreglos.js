var num = [1, 2, 3, 4, 5];

var letra = ["jirafa", "perro", "sapo"];

console.log(letra[0]);

var mixto = ["perro", 56, "Jose"];

/////////////////////////////////////////////////////////////////////////////

var perro = { raza: "doberman", color: "negro", edad: 5 };

console.log(perro.raza);

var anidado = { anidado1: { anidado2: { anidado3: "perro" } } };

console.log(anidado.anidado1.anidado2.anidado3);

var cubica = [];

for (let index = 0; index < num.length; index++) {
  cubica[index] = num[index] ** 3;

  console.log("El numero cubico de " + num[i] + " es " + cubico[i]);
}

console.log(cubica);

var sapo = [];

for (let index = 0; index < 10; index++) {
  sapo[index] = parseInt(prompt("Ingrese el numero " + (index + 1)));
}

console.log(sapo);

////////matrices//////////////////

var tabla = [];

for (let fila = 0; fila < 4; fila++) {
  console.log("Creando fila " + (fila + 1));
  tabla[fila] = [];
  for (let columna = 0; columna < 2; columna++) {
    console.log(
      "Esta insertando datos en la fila " +
        (fila + 1) +
        " y columna " +
        (columna + 1)
    );
    tabla[fila][columna] = prompt("Ingrese algo");
    console.log(
      "Se ingresaron los datos de la fila " +
        (fila + 1) +
        " y columna " +
        (columna + 1)
    );
  }
}
console.log(tabla);

///////////////////////////////taller///////////////////////////////////

var vector = [];
var sum = 0;

for (let index = 0; index < 10; index++) {
  vector[index] = parseInt(prompt("Ingrese el numero " + (index + 1)));
  while (isNaN(vector[index])) {
    vector[index] = parseInt(prompt("Ingrese el numero " + (index + 1)));
  }
  sum = vector[index] + sum;
}

console.log("La sumatoria de los 10 numeros es: " + sum);

///////////////////////////////////////////////////////

var numeros = [];
var contador = 0;

for (let index = 0; index < 10; index++) {
  numeros[index] = parseInt(prompt("Ingrese el numero " + (index + 1)));
  while (isNaN(numeros[index])) {
    numeros[index] = parseInt(prompt("Ingrese el numero " + (index + 1)));
  }

  if (numeros[index] > 0) {
    contador = contador + 1;
  }
}

console.log("La cantidad de numeros positivos es: " + contador);

//////////////////////////////////////////////////////

var matrix = [];

for (let fila = 0; fila < 3; fila++) {
  matrix[fila] = [];
  for (let columna = 0; columna < 3; columna++) {
    matrix[fila][columna] = parseInt(
      prompt(
        "Ingrese el numero para la posicion: " +
          (fila + 1) +
          "." +
          (columna + 1)
      )
    );
  }
}

console.log(matrix);

////////////////////////////////////////////////////////////////

var notas = [];
promedio = 0;

for (let index = 0; index < 5; index++) {
  notas[index] = parseFloat(prompt("Ingrese la nota " + (index + 1)));
  while (isNaN(notas[index]) || notas[index] < 0 || notas[index] > 5) {
    notas[index] = parseFloat(prompt("Ingrese la nota " + (index + 1)));
  }

  promedio = notas[index] + promedio;
}

promedio = promedio / 5;

if (promedio >= 0 && promedio <= 2.9) {
  console.log("Su nota es de: " + promedio);
  console.log("Su nota es Deficiente para pasar");
} else {
  if (promedio >= 3 && promedio <= 3.9) {
    console.log("Su nota es de: " + promedio);
    console.log("Su nota es Aceptable para pasar");
  } else {
    if (promedio >= 4 && promedio <= 4.5) {
      console.log("Su nota es de: " + promedio);
      console.log("Su nota es Sobresaliente para pasar");
    } else {
      console.log("Su nota es de: " + promedio);
      console.log("Su nota es Excelente para pasar");
    }
  }
}

/////////////////////////////////////////////////////////////

var matriz = [];

for (let index = 0; index < 10; index++) {
  matriz[index] = parseInt(prompt("Ingrese el numero " + (index + 1)));
  while (isNaN(matriz[index])) {
    matriz[index] = parseInt(prompt("Ingrese el numero " + (index + 1)));
  }
}

console.log(matriz);

var adivineishon = parseInt(
  prompt("Ingrese el numero que desea buscar en el array")
);

for (let index = 0; index < 10; index++) {
  if (adivineishon === matriz[index]) {
    console.log(
      "El numero : " + adivineishon + " Se encuenta en la posicion: " + index
    );
  } else {
    console.log("El numero digitado no se encuentra en la matriz");
  }
}

/////////////////////////////////////////////

var aleatorios = [];
var numerito = 0;

d = parseInt(prompt("Digite la cantidad de numeros que quiere generar"));
while (isNaN(d)) {
  d = parseInt(prompt("Digite la cantidad de numeros que quiere generar"));
}

for (let i = 0; i < d; i++) {
  aleatorios[i] = Math.floor(Math.random() * 100 - 0);
}

console.log(aleatorios);

for (let j = 0; j < d; j++) {
  for (let i = 0; i < d; i++) {
    if (aleatorios[i] > aleatorios[i + 1]) {
      numerito = aleatorios[i];
      aleatorios[i] = aleatorios[i + 1];
      aleatorios[i + 1] = numerito;
    }
  }
}

console.log(aleatorios);

///////////////////////////////////////////////////////////

var vector_numeros = [];
var cuadrado = [];
var cubo = [];

for (let i = 0; i < 10; i++) {
  vector_numeros[i] = Math.floor(Math.random() * 10 - 1);

  cuadrado[i] = vector_numeros[i] * vector_numeros[i];

  cubo[i] = vector_numeros[i] ^ 3;
}
console.log("Array generado: " + vector_numeros);
console.log("Array con los cuadrados: " + cuadrado);
console.log("Array con los cubos: " + cubo);

////////////////////////////////////////////////////////77

var palabras = [];
var otrovector = [];

for (let i = 0; i < 5; i++) {
  palabras[i] = prompt("Ingrese la palabra o el caracter " + (i + 1));
  while (!isNaN(palabras[i])) {
    palabras[i] = prompt("Ingrese la palabra o el caracter " + (i + 1));
  }
}

for (let i = 4; i >= 0; i++) {
  
}
