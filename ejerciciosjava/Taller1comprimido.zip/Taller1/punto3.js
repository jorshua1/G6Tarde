base = parseInt(prompt("Ingrese el valor de la base"));
altura = parseInt(prompt("Ingrese el valor de la altura"));
area = base * altura / 2;
console.log(area);
