let nota1 = parseFloat(prompt("ingrese la primera nota"));
let nota2 = parseFloat(prompt("ingrese la nota numero 2"));
let nota3 = parseFloat(prompt("ingrese la nota numero 3"));
let nota4 = parseFloat(prompt("ingrese la nota numero 4"));
let porcentaje1 = (nota1+nota2)*0.4/2;
let porcentaje2 = (nota3+nota4)*0.6/2;
let definitiva = porcentaje1+porcentaje2;
console.log(definitiva);

