//punto 1 del primero

let A = 2;
let B = 5;
let C = 1;
let Respuesta = (3*A)-(4*B)/(A**2)
console.log(Respuesta);

//punto 2 del primero

let Respuesta2 = B+C/2*A+10*3*B-6;
console.log(Respuesta2);