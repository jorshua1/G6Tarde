let edad = parseInt(prompt("Ingrese la edad"));
numpulsaciones = (220-edad)/10;
console.log("El numero de las pulsaciones es; " + numpulsaciones);
