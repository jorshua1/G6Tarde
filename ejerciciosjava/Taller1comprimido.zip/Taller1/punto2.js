Capital = parseInt(prompt("Ingrese su Capital"));
Gancia = Capital*0.012;
console.log(Gancia);